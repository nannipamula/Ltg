CKEDITOR.plugins.setLang('markTag', 'en', {
  button: 'Marked Text',
})
