CKEDITOR.plugins.setLang('markTag', 'de', {
  button: 'Markierter Text',
})
