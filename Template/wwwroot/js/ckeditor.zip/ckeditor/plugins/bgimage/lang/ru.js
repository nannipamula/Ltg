
CKEDITOR.plugins.setLang('bgimage','ru',{
	bgImageTitle : 'Фоновое изображение',
	imageUrl     : 'URL изображения',
	repeat	     : 'Повторение',
	attachment   : 'Привязка',
	blendMode    : 'Режим наложения',
	position	 : 'Позиция'
})
