CKEDITOR.plugins.setLang('imagerotate', 'fr', {
  rotateRight: 'Rotation horaire',
  rotateLeft: 'Rotation antihoraire'
});
