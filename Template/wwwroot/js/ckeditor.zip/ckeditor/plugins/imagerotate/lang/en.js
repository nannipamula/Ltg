﻿CKEDITOR.plugins.setLang('imagerotate', 'en', {
  rotateRight: 'Rotate Clockwise',
  rotateLeft: 'Rotate Counter-clockwise'
});
