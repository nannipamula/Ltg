/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","bg",{
	"alt":"Алтернативен текст",
	"lockRatio":"Заключване на съотношението",
	"vSpace":"Вертикален отстъп",
	"hSpace":"Хоризонтален отстъп",
	"border":"Рамка"
});